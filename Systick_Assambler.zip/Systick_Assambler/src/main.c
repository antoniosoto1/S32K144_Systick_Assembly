/*
 * main implementation: use this 'C' sample to create your own application
 *
 */


#include "S32K144.h" /* include peripheral declarations S32K144 */

void EnableInterrupts(void);  // Enable interrupts
void WaitForInterrupt(void);
void WDOG_disable (void);
void PORT_init (void);
void SysTick_Init(void);

#define LED_COLOR  16 /*0 blue, 15 RED, 16 Green */

volatile unsigned long Counts = 0;


void SysTick_Handler(void){
  PTD->PTOR |= 1<<LED_COLOR;                /* Toggle PD15 (LED RED) Port Toggle Output Register (PTOR)
  	  	  	  	  	  	  	  	  	  	1b - Corresponding bit in PDORn is set to the inverse of its existing logic state. */
  Counts = Counts + 1;
}


int main(void)
{
	WDOG_disable();

	PORT_init ();

	SysTick_Init();        // SysTick timer Init

	EnableInterrupts();

	  while(1){                   // interrupts every 1ms, 500 Hz flash
	    WaitForInterrupt();
	  }

    /* to avoid the warning message for GHS and IAR: statement is unreachable*/
#if defined (__ghs__)
#pragma ghs nowarning 111
#endif
#if defined (__ICCARM__)
#pragma diag_suppress=Pe111
#endif
	return 0;
}
